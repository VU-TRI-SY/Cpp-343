/**
 * Driver for tests
 */

#include <iostream>

using namespace std;

// forward declaration, implementation in xxxtest.cpp
void testAll();

int main() {
  testAll();
  cout << "Done!" << endl;
  return 0;
}
